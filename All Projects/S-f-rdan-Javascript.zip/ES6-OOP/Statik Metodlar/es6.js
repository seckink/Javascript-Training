// Statik Metodlar

class Matematik {
    sqrt(x){
        console.log(x*x);
    }
    static cube(x) {
        console.log(x*x*x);
    }
}
// const math = new Matematik();
// Matematik.cube(3);
// console.log(math);

// math.sqrt(4);
// Matematik.sqrt(5);

// Object.create();

console.log(Math.sqrt(4));