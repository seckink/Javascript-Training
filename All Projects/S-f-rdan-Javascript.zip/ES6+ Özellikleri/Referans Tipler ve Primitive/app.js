// let a = "Mustafa";
// let b = "Mustafa";

// if (a === b) {
//     console.log("Eşit");
// }

// const person1 = {
//     name:"Mustafa",
//     age:25
// }
// const person2 = {
//     name:"Mustafa",
//     age:25
// }

// if(person1 === person2) {
//     console.log("Eşit");
// }

// const cities = new Map();
// const key = [1,2,3];
// cities.set("Ankara",5);
// cities.set("İstanbul",15);
// cities.set(key,"Array")

// console.log(cities.get(key));
