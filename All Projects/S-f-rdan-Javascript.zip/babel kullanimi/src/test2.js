async function test(){

    return "Merhaba";
}
test();
