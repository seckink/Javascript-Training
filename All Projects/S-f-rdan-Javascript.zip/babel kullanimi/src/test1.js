// ES6

class Person {

    static test(){
        console.log("Test");
    }
}