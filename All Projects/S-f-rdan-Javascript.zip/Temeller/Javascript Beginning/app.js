alert("Javascript'e Hoışgeldiniz...");
var a = 10;

alert(a);
