let value;


const value1 = 10;

const value2 = 4;

// Aritmetik Operatörler

// value = value1 + value2;
// value = value1 - value2;
// value = value1 * value2;
// value = value1 / value2;
// value = value1 % value2;


value = Math.PI;
value = Math.E;

value = Math.round(3.6);
value = Math.round(3.5);
value = Math.round(3.2);



value = Math.ceil(3.2);
value = Math.ceil(3.7);

value = Math.floor(3.2);
value = Math.floor(3.7);


value = Math.sqrt(16);
value = Math.sqrt(31);

value = Math.abs(-10);

value = Math.pow(8,3);
value = Math.pow(4,2);

value = Math.max(10,-1,100,32);
value = Math.min(10,-1,100,32);


value = Math.random();

value = Math.floor(Math.random() * 20 + 1);




console.log(value);

