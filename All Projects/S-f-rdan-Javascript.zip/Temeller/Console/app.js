// console.log("Merhaba Javascript");
// console.log(213213);
// console.log(true);
// console.log(false);

// var a = 20;

// console.log(a);

// console.log(["Ahmet","Mehmet"]);

// console.log(typeof a);

console.warn("Bu bir uyarıdır.");
console.error("Bu sayfa bulunamadı");
console.clear();







