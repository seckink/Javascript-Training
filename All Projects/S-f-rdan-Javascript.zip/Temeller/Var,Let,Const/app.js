// Var 

// var name = "Mustafa Murat";
// console.log(name);

// name = "Murat";

// console.log(name);

// Let

// let a,b;

// a = 10;
// b = 20;

// console.log(a+b);

// Const

// const name = "Mustafa Murat";

// console.log(name);

// name = "Murat";

// console.log(name);

const a = [1,2,3,4,5];

console.log(a);

a.push(6);

const b = 10;

b = 20;

console.log(a);






