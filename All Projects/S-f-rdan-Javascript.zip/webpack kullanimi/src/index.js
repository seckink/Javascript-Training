// CommonJs Modülleri

// const app = require("./module1");

// console.log(app.name);
// app.test1();
// console.log(app.person.name);

// ES6 Modules

// import {test,Person,employee,name} from "./module1";

// import * as module1 from "./module1";

// console.log(module1);
// console.log(module1.employee.salary);
// module1.Person.Test();

// import Deneme from "./module1";
// Deneme.deneme();

import denemeVal from "./module1";

console.log(denemeVal);
