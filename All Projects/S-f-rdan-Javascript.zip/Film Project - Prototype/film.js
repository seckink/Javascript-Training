// Film Constructor
function Film(title,director,url){
    this.title = title;
    this.director = director;
    this.url = url;

}